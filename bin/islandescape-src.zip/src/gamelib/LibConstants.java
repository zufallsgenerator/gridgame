package gamelib;

/**
 * Constants for gamelib, currently only one
 * 
 * @author Christer Bystr�m
 * 
 */
public class LibConstants {
	public static final int TICKS_PER_SECOND = 50;

}
